<?php

namespace App\Http\Middleware\jwt;

use Closure;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Facades\JWTAuth;

class PermissionAuthorization
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next, $module, $permission)
    {
        try {

            //Access token from the request
            $token = JWTAuth::parseToken();
            //Try authenticating user
            $user = $token->authenticate();
            if ($user->isAdmin()) {
                return $next($request);
            }

            foreach ($user->roles()->get() as $role) {
                $Permission = $role->permissions()->where('nomModule', $module)->get()->first();
                if ($Permission) {
                    error_log($Permission->pivot);
                    if ($permission == "read") {
                        if ($Permission->pivot->read) {
                            error_log("readmoh akjdnajdnajkzndjkza");
                            return $next($request);
                        }
                    }
                    if ($permission == "edit") {
                        if ($Permission->pivot->edit) {
                            error_log("editmoh akjdnajdnajkzndjkza");
                            return $next($request);
                        }
                    }
                    if ($permission == "delete") {
                        if ($Permission->pivot->delete) {
                            error_log("deletemoh akjdnajdnajkzndjkza");
                            return $next($request);
                        }
                    }

                }
            }
//            error_log($module);

        } catch (TokenExpiredException $e) {

            //Thrown if token has expired
            return $this->unauthorized('Your token has expired. Please, login again.');

        } catch
        (TokenInvalidException $e) {

            //Thrown if token invalid
            return $this->unauthorized('Your token is invalid. Please, login again.');

        } catch (JWTException $e) {

            //Thrown if token was not found in the request.
            return $this->unauthorized('Please, attach a Bearer Token to your request');
        }

        //If user was authenticated successfully and user is in one of the acceptable roles, send to next request.
//        if ($user && in_array($user->role, $role)) {
//            return $next($request);
//        }

        return $this->unauthorized();
    }

    private function unauthorized($message = null)
    {
        return response()->json([
            'message' => $message ? $message : 'You are unauthorized to access this resource',
            'success' => false
        ], 401);
    }
}
