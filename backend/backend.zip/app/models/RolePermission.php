<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class RolePermission extends Model 
{

    protected $table = 'role_permission';
    public $timestamps = true;

}